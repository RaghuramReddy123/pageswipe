//
//  Constatnts.swift
//  webServiceSwift
//
//  Created by Raghu Ram on 07/06/18.
//  Copyright © 2018 Raghu Ram. All rights reserved.
//

import Foundation
import UIKit


let BASE_URL = "http://192.168.1.66/veekshanam/api/"
let GETACTIVITIES_URL = BASE_URL+"activity/getactivities"
