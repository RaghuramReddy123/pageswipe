
//
//  SSAConstants.swift
//  DemoForWebserives
//
//  Created by Prasanth on 07/06/18.
//  Copyright © 2018 iconma. All rights reserved.
//

import Foundation
import UIKit


let appDelegate = UIApplication.shared.delegate as! AppDelegate

let BASE_URL = "http://192.168.1.66/veekshanam/api/"
let GETACTIVITIES_URL = BASE_URL+"activity/getactivities"
