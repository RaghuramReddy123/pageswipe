//
//  SecondViewController.swift
//  PageSwipe
//
//  Created by Raghu Ram on 24/09/18.
//  Copyright © 2018 Raghu Ram. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    var resultarray1 = Array<Any>()
    
    var loader = LoaderView()

    @IBOutlet weak var secondTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.secondTableView.tableFooterView = UIView()
        senddatoServer()
    }
    
    func senddatoServer()
    {
        loader = LoaderView.instanceFromNib() as! LoaderView
        loader.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
        appDelegate.window?.addSubview(loader)

        self.loader.activityIndicatorOBJ.startAnimating()
        
        let dict = ["school_id": "36550", "inspection_id": "13463"]
        WebserivesHandler.sharedInstance.sampleBlocks(httpMethodType: "GET", urlString: "https://rss.itunes.apple.com/api/v1/us/apple-music/hot-tracks/all/10/explicit.json", params: dict as [String : AnyObject], success: { (responseOBJ) in
            
            self.resultarray1 = (((responseOBJ["feed"] as AnyObject).value(forKey: "results")) as AnyObject?) as! [Any]
            
            //print("array is :-\(self.resultarray1)")
         
            DispatchQueue.main.async {
                
                self.loader.activityIndicatorOBJ.stopAnimating()
                self.loader.removeFromSuperview()
                self.secondTableView .reloadData()
                
            }
            
        }) { (error) in
            
            print(error)
            
        }
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return resultarray1.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.secondTableView.dequeueReusableCell(withIdentifier: "DataCell") as! DataCell
        
        let resultdata = resultarray1[indexPath.row]
        print("array is :-\(resultdata)")
        cell.artistId.text! = (resultdata as AnyObject).value(forKey: "artistId")! as! String
        cell.Artistname.text! = (resultdata as AnyObject).value(forKey: "artistName")! as! String
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return 80
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
