//
//  ViewController.swift
//  PageSwipe
//
//  Created by Raghu Ram on 24/09/18.
//  Copyright © 2018 Raghu Ram. All rights reserved.
//

import UIKit

class ViewController: UIViewController,CAPSPageMenuDelegate {
    var pageMenu:CAPSPageMenu?
    var viewControllersArray:[UIViewController] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
          self.viewControllersRegister()
    }
    func viewControllersRegister(){
        
        
        let firstVC:firstViewController = self.storyboard?.instantiateViewController(withIdentifier: "firstViewController") as! firstViewController
        firstVC.title = "FIRST VC"
        viewControllersArray.append(firstVC)
        let secondVC:SecondViewController = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        secondVC.title = "SECOND VC"
        viewControllersArray.append(secondVC)
        let thirdVC:ThirdViewController = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        thirdVC.title = "THIRD VC"
        viewControllersArray.append(thirdVC)
        
        
        let parameters: [CAPSPageMenuOption] = [
            CAPSPageMenuOption.menuItemSeparatorWidth(2.3),
            CAPSPageMenuOption.menuItemWidth(self.view.frame.size.width/2.8),
            CAPSPageMenuOption.menuItemSeparatorPercentageHeight(0.1),
            CAPSPageMenuOption.viewBackgroundColor(UIColor.white),
            CAPSPageMenuOption.scrollMenuBackgroundColor(UIColor(red: 46.0/255, green: 120.0/255, blue: 236.0/255, alpha: 1.0)),
            CAPSPageMenuOption.selectionIndicatorColor(UIColor.white),
            CAPSPageMenuOption.menuHeight(45.0),
            CAPSPageMenuOption.addBottomMenuHairline(true),
            .menuItemFont(UIFont(name: "HelveticaNeue-Medium", size: 14.0)!),
            CAPSPageMenuOption.menuMargin(1.0),
            CAPSPageMenuOption.selectedMenuItemLabelColor(UIColor.white),
            
            CAPSPageMenuOption.unselectedMenuItemLabelColor(UIColor.orange),
            CAPSPageMenuOption.scrollAnimationDurationOnMenuItemTap(500)
        ]
        
        pageMenu = CAPSPageMenu(viewControllers: viewControllersArray, frame: CGRect(x:0.0, y:64.0, width: self.view.frame.size.width, height:self.view.frame.size.height), pageMenuOptions: parameters)
        self.view.addSubview(pageMenu!.view)
        pageMenu!.delegate = self
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func didMoveToPage(_ controller: UIViewController, index: Int) {
        print("Current Page index :- \(index)")
    }


}

