//
//  DataCell.swift
//  DemoForWebserives
//
//  Created by Raghu Ram on 08/06/18.
//  Copyright © 2018 iconma. All rights reserved.
//

import UIKit

class DataCell: UITableViewCell {

    @IBOutlet weak var artistId: UILabel!
    @IBOutlet weak var Artistname: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
