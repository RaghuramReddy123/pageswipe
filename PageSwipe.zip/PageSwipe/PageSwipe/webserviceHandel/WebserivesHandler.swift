//
//  WebserivesHandler.swift
//  DemoForWebserives
//
//  Created by Prasanth on 07/06/18.
//  Copyright © 2018 iconma. All rights reserved.
//

import UIKit

class WebserivesHandler: NSObject {
    static let sharedInstance:WebserivesHandler = WebserivesHandler()
    
    func sampleMethod(){
        
    }
    func sampleMethod(urlSTR:String){
        
    }
    func sampleMethod(urlSTR:String)-> String{
        
        return urlSTR
        
    }

    func sampleMethod()-> String{
        
        return "urlSTR"
        
    }
    
    //////Blocks
    
    func sampleBlocks(httpMethodType:String,urlString:String,params:[String:AnyObject]?,success:@escaping(_ SuccessJsonResult:AnyObject) ->Void,failure:@escaping(_ failureResult:AnyObject) -> Void){
        
        print(urlString)
        print(params)
        
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = TimeInterval(60)
        configuration.timeoutIntervalForResource = TimeInterval(60)
        let session = URLSession(configuration: configuration)
        
        // let session = URLSession.shared
        let Url = String(format: urlString)
        guard let serviceUrl = URL(string: Url) else { return }
        var request = URLRequest(url: serviceUrl)
        request.httpMethod = "GET"
//        do {
//            request.httpBody = try JSONSerialization.data(withJSONObject: params!, options: .prettyPrinted)
//        } catch let error {
//            print(error.localizedDescription)
//        }
        let loginString = String(format: "%@:%@", "admin", "1234")
        let loginData = loginString.data(using: String.Encoding.utf8)!
        let base64LoginString = loginData.base64EncodedString()
        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        let task = session.dataTask(with: request as URLRequest, completionHandler: { data, response, error in
            guard error == nil else {
                return
            }
            guard let data = data else {
                return
            }
            do {
                //create json object from data
                if let jsonDict = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] {
                    print(jsonDict)
                    
                    if let status = jsonDict["status"] as? String {
                        
                        print(status)
                        failure(jsonDict as AnyObject)
                    }else{
                        success(jsonDict as AnyObject)
                    }
                    
                }
            } catch let error {
                print(error.localizedDescription)
                failure(error.localizedDescription as AnyObject)
            }
        })
        task.resume()
        
    }
}
