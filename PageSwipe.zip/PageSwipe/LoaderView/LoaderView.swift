//
//  LoaderView.swift
//  ZeeesselGroupTest
//
//  Created by Prasanth on 01/08/18.
//  Copyright © 2018 iconma. All rights reserved.
//

import UIKit

class LoaderView: UIView {

    @IBOutlet weak var activityIndicatorOBJ: UIActivityIndicatorView!
    class func instanceFromNib() -> UIView {
        return UINib(nibName: "LoaderView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }


   
}
